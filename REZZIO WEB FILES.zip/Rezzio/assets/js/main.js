$('.ui.dropdown')
    .dropdown({
        values: [
            {
                name: 'Male',
                value: 'male'
            },
            {
                name     : 'Female',
                value    : 'female',
                selected : true
            }
        ]
    })
;